<?php

namespace Barryvdh\DomPDF;

use Barryvdh\DomPDF\Facade\Pdf as PdfFacade;

/**
 * @deprecated use \Barryvdh\DomPDF\Facade\Pdf instead
 */
class Facade extends PdfFacade
{
}
